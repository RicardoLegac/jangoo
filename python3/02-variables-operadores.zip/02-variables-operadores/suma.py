print('Suma de dos números enteros')

# Entrada de datos 
a = input('Ingrese primer número: ')
b = input('Ingrese segundo número: ')

#Operación 
a = int(a)
b = int(b)

suma = a + b

#Salida 
#print(type(a))
print('La suma es:', suma)
