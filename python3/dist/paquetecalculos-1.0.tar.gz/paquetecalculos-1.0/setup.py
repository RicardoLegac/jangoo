from setuptools import setup
setup(
    name="paquetecalculos", #nombre del paquete
    version =  "1.0",
    description= "calculos basicos",
    author="Ricardo", 
    packages=["calculos","operaciones"]

)