def suma(op1,op2):
    return op1+op2
def resta(op1,op2):
    return op1-op2
def redondeo(num):
    return round(num)